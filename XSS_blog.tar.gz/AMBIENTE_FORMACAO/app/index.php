<?php
$host = getenv('DB_HOST') ?: 'mysql';
$db   = getenv('DB_DATABASE') ?: 'appdb';
$user = getenv('DB_USERNAME') ?: 'appuser';
$pass = getenv('DB_PASSWORD') ?: 'secret';

echo "<h1>🐳 Stack LEMP a funcionar!</h1>";
echo "<p><strong>PHP:</strong> " . phpversion() . "</p>";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    echo "<p style='color:green'>✅ Ligação à base de dados MySQL bem-sucedida!</p>";
} catch (PDOException $e) {
    echo "<p style='color:red'>❌ Erro de ligação: " . $e->getMessage() . "</p>";
}
