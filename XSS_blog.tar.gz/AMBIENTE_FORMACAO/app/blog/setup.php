<?php
// ─────────────────────────────────────────────────────────────
//  setup.php — Corre UMA VEZ para criar tabelas e utilizador admin
//  Acede a: http://IP/admin/setup.php
//  APAGA este ficheiro depois de executar!
// ─────────────────────────────────────────────────────────────

$host = getenv('DB_HOST')     ?: 'mysql';
$db   = getenv('DB_DATABASE') ?: 'appdb';
$user = getenv('DB_USERNAME') ?: 'appuser';
$pass = getenv('DB_PASSWORD') ?: 'secret';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Erro BD: " . $e->getMessage());
}

$pdo->exec("
    CREATE TABLE IF NOT EXISTS users (
        id        INT AUTO_INCREMENT PRIMARY KEY,
        username  VARCHAR(50)  NOT NULL UNIQUE,
        password  VARCHAR(255) NOT NULL,
        role      ENUM('admin','editor') DEFAULT 'editor',
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS posts (
        id        INT AUTO_INCREMENT PRIMARY KEY,
        titulo    VARCHAR(255) NOT NULL,
        conteudo  TEXT NOT NULL,
        autor_id  INT  NOT NULL,
        estado    ENUM('rascunho','publicado') DEFAULT 'rascunho',
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (autor_id) REFERENCES users(id)
    )
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS comentarios (
        id        INT AUTO_INCREMENT PRIMARY KEY,
        post_id   INT          NOT NULL,
        autor     VARCHAR(100) NOT NULL,
        mensagem  TEXT         NOT NULL,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
    )
");

// Cria admin com hash bcrypt real
$hash = password_hash('noodleboy', PASSWORD_BCRYPT);
$stmt = $pdo->prepare("INSERT IGNORE INTO users (username, password, role) VALUES (?, ?, 'admin')");
$stmt->execute(['admin', $hash]);

// Mostra a query SQL equivalente
echo "<pre style='background:#2c3e50;color:#2ecc71;padding:15px;border-radius:6px'>";
echo "✅ Tabelas criadas e admin inserido!\n\n";
echo "-- Query SQL equivalente (para referência):\n";
echo "INSERT INTO users (username, password, role)\n";
echo "VALUES ('admin', '$hash', 'admin');\n";
echo "</pre>";
echo "<p style='color:red'><strong>⚠️ Apaga este ficheiro agora: rm /var/www/html/admin/setup.php</strong></p>";
?>
