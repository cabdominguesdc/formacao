<?php require 'auth.php'; ?>
<?php
// ─── Ações ────────────────────────────────────────────────────

// Apagar post
if (isset($_GET['apagar'])) {
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([(int)$_GET['apagar']]);
    header('Location: index.php?msg=apagado');
    exit;
}

// Apagar comentário
if (isset($_GET['apagar_com'])) {
    $stmt = $pdo->prepare("DELETE FROM comentarios WHERE id = ?");
    $stmt->execute([(int)$_GET['apagar_com']]);
    header('Location: index.php?msg=com_apagado');
    exit;
}

// Alternar estado do post
if (isset($_GET['toggle'])) {
    $stmt = $pdo->prepare("UPDATE posts SET estado = IF(estado='publicado','rascunho','publicado') WHERE id = ?");
    $stmt->execute([(int)$_GET['toggle']]);
    header('Location: index.php');
    exit;
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$posts       = $pdo->query("SELECT p.*, u.username FROM posts p JOIN users u ON p.autor_id=u.id ORDER BY p.criado_em DESC")->fetchAll(PDO::FETCH_ASSOC);
$total_posts = count($posts);
$publicados  = count(array_filter($posts, fn($p) => $p['estado'] === 'publicado'));
$rascunhos   = $total_posts - $publicados;
$total_coms  = $pdo->query("SELECT COUNT(*) FROM comentarios")->fetchColumn();
$comentarios = $pdo->query("SELECT c.*, p.titulo FROM comentarios c JOIN posts p ON c.post_id=p.id ORDER BY c.criado_em DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Blog Admin – Dashboard</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; background: #f0f2f5; }

        /* Sidebar */
        .sidebar { width: 220px; background: #2c3e50; min-height: 100vh; position: fixed; top: 0; left: 0; }
        .sidebar .logo { padding: 24px 20px; color: white; font-size: 18px; font-weight: bold; border-bottom: 1px solid #3d5166; }
        .sidebar .logo span { color: #8e44ad; }
        .sidebar nav a { display: block; padding: 12px 20px; color: #bdc3c7; text-decoration: none; font-size: 14px; transition: background .2s; }
        .sidebar nav a:hover, .sidebar nav a.active { background: #8e44ad; color: white; }
        .sidebar .user-info { position: absolute; bottom: 0; width: 100%; padding: 14px 20px; border-top: 1px solid #3d5166; color: #bdc3c7; font-size: 12px; }
        .sidebar .user-info a { color: #e74c3c; text-decoration: none; }

        /* Main */
        .main { margin-left: 220px; padding: 30px; }
        h1 { color: #2c3e50; font-size: 24px; margin-bottom: 6px; }
        .breadcrumb { color: #999; font-size: 13px; margin-bottom: 24px; }

        /* Cards de estatísticas */
        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 30px; }
        .stat-card { background: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 6px rgba(0,0,0,.08); border-left: 4px solid #8e44ad; }
        .stat-card .num { font-size: 32px; font-weight: bold; color: #2c3e50; }
        .stat-card .label { font-size: 12px; color: #999; margin-top: 4px; }
        .stat-card.green { border-color: #27ae60; }
        .stat-card.orange { border-color: #f39c12; }
        .stat-card.red { border-color: #e74c3c; }

        /* Tabelas */
        .section { background: white; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,.08); margin-bottom: 24px; }
        .section-header { padding: 16px 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }
        .section-header h2 { font-size: 16px; color: #2c3e50; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8f9fa; padding: 10px 16px; text-align: left; font-size: 12px; color: #666; text-transform: uppercase; border-bottom: 1px solid #eee; }
        td { padding: 12px 16px; font-size: 14px; border-bottom: 1px solid #f5f5f5; vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #fafafa; }

        /* Badges */
        .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .badge.pub { background: #d5f5e3; color: #27ae60; }
        .badge.ras { background: #fdebd0; color: #f39c12; }

        /* Botões */
        .btn { padding: 5px 12px; border-radius: 4px; font-size: 12px; text-decoration: none; border: none; cursor: pointer; display: inline-block; }
        .btn-edit { background: #3498db; color: white; }
        .btn-del { background: #e74c3c; color: white; }
        .btn-tog { background: #f39c12; color: white; }
        .btn-new { background: #8e44ad; color: white; padding: 8px 16px; font-size: 13px; border-radius: 6px; text-decoration: none; }
        .btn:hover { opacity: .85; }

        /* Alerta */
        .alert { background: #d5f5e3; color: #27ae60; padding: 10px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 13px; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="logo">📝 Blog<span>Admin</span></div>
    <nav>
        <a href="index.php" class="active">📊 Dashboard</a>
        <a href="post_novo.php">✏️ Novo Post</a>
        <a href="posts.php">📄 Todos os Posts</a>
        <a href="comentarios.php">💬 Comentários</a>
    </nav>
    <div class="user-info">
        👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= $_SESSION['role'] ?>)<br>
        <a href="?logout=1">Sair →</a>
    </div>
</div>

<div class="main">
    <h1>Dashboard</h1>
    <div class="breadcrumb">Blog Admin › Dashboard</div>

    <?php if (isset($_GET['msg'])): ?>
    <div class="alert">✅ Operação realizada com sucesso.</div>
    <?php endif; ?>

    <!-- Estatísticas -->
    <div class="stats">
        <div class="stat-card">
            <div class="num"><?= $total_posts ?></div>
            <div class="label">Total de Posts</div>
        </div>
        <div class="stat-card green">
            <div class="num"><?= $publicados ?></div>
            <div class="label">Publicados</div>
        </div>
        <div class="stat-card orange">
            <div class="num"><?= $rascunhos ?></div>
            <div class="label">Rascunhos</div>
        </div>
        <div class="stat-card red">
            <div class="num"><?= $total_coms ?></div>
            <div class="label">Comentários</div>
        </div>
    </div>

    <!-- Posts recentes -->
    <div class="section">
        <div class="section-header">
            <h2>📄 Posts Recentes</h2>
            <a href="post_novo.php" class="btn-new">+ Novo Post</a>
        </div>
        <table>
            <tr>
                <th>#</th><th>Título</th><th>Autor</th><th>Estado</th><th>Data</th><th>Ações</th>
            </tr>
            <?php if (empty($posts)): ?>
            <tr><td colspan="6" style="text-align:center;color:#999;padding:24px">Ainda não há posts. <a href="post_novo.php">Cria o primeiro!</a></td></tr>
            <?php endif; ?>
            <?php foreach (array_slice($posts, 0, 8) as $p): ?>
            <tr>
                <td><?= $p['id'] ?></td>
                <td><?= htmlspecialchars($p['titulo']) ?></td>
                <td><?= htmlspecialchars($p['username']) ?></td>
                <td><span class="badge <?= $p['estado']==='publicado' ? 'pub' : 'ras' ?>"><?= $p['estado'] ?></span></td>
                <td><?= date('d/m/Y H:i', strtotime($p['criado_em'])) ?></td>
                <td>
                    <a href="post_editar.php?id=<?= $p['id'] ?>" class="btn btn-edit">Editar</a>
                    <a href="?toggle=<?= $p['id'] ?>" class="btn btn-tog"><?= $p['estado']==='publicado' ? 'Despublicar' : 'Publicar' ?></a>
                    <a href="?apagar=<?= $p['id'] ?>" class="btn btn-del" onclick="return confirm('Apagar este post?')">Apagar</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <!-- Comentários recentes -->
    <div class="section">
        <div class="section-header">
            <h2>💬 Comentários Recentes</h2>
            <a href="comentarios.php" style="font-size:13px;color:#8e44ad">Ver todos →</a>
        </div>
        <table>
            <tr><th>Autor</th><th>Post</th><th>Mensagem</th><th>Data</th><th>Ação</th></tr>
            <?php if (empty($comentarios)): ?>
            <tr><td colspan="5" style="text-align:center;color:#999;padding:24px">Sem comentários.</td></tr>
            <?php endif; ?>
            <?php foreach ($comentarios as $c): ?>
            <tr>
                <td><?= htmlspecialchars($c['autor']) ?></td>
                <td><?= htmlspecialchars($c['titulo']) ?></td>
                <td><?= htmlspecialchars(mb_strimwidth($c['mensagem'], 0, 60, '...')) ?></td>
                <td><?= date('d/m/Y H:i', strtotime($c['criado_em'])) ?></td>
                <td><a href="?apagar_com=<?= $c['id'] ?>" class="btn btn-del" onclick="return confirm('Apagar comentário?')">Apagar</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>

</body>
</html>
