<?php
ob_start();
$host = getenv('DB_HOST')     ?: 'mysql';
$db   = getenv('DB_DATABASE') ?: 'appdb';
$user = getenv('DB_USERNAME') ?: 'appuser';
$pass = getenv('DB_PASSWORD') ?: 'secret';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Erro BD: " . $e->getMessage()); }

$hash = password_hash('victim', PASSWORD_BCRYPT);
$stmt = $pdo->prepare("INSERT IGNORE INTO users (username, password, role) VALUES (?, ?, 'editor')");
$stmt->execute(['victim', $hash]);
$stmt->execute(['aluno', $hash]);

echo "<pre style='background:#2c3e50;color:#2ecc71;padding:20px;border-radius:6px;font-size:14px'>";
echo "✅ Utilizador 'victim' criado!\n\n";
echo "-- SQL equivalente:\n";
echo "INSERT INTO users (username, password, role)\n";
echo "VALUES ('victim', '$hash', 'editor');\n";
echo "</pre>";
echo "<p style='color:red;font-family:Arial'><strong>⚠️ Apaga este ficheiro: rm /var/www/html/admin/add_victim.php</strong></p>";
ob_end_flush();
