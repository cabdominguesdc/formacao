<?php
ob_start();
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Ligação à base de dados partilhada por todas as páginas admin
$host = getenv('DB_HOST')     ?: 'mysql';
$dbname = getenv('DB_DATABASE') ?: 'appdb';
$dbuser = getenv('DB_USERNAME') ?: 'appuser';
$dbpass = getenv('DB_PASSWORD') ?: 'secret';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Erro BD: " . $e->getMessage());
}
