<?php require 'auth.php'; ?>
<?php
$erro = '';
$ok   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo   = trim($_POST['titulo']   ?? '');
    $conteudo = trim($_POST['conteudo'] ?? '');
    $estado   = $_POST['estado'] === 'publicado' ? 'publicado' : 'rascunho';

    if ($titulo && $conteudo) {
        $stmt = $pdo->prepare("INSERT INTO posts (titulo, conteudo, autor_id, estado) VALUES (?, ?, ?, ?)");
        $stmt->execute([$titulo, $conteudo, $_SESSION['user_id'], $estado]);
        header('Location: index.php?msg=criado');
        exit;
    } else {
        $erro = 'Preenche o título e o conteúdo.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Novo Post – Blog Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; background: #f0f2f5; }
        .sidebar { width: 220px; background: #2c3e50; min-height: 100vh; position: fixed; top: 0; left: 0; }
        .sidebar .logo { padding: 24px 20px; color: white; font-size: 18px; font-weight: bold; border-bottom: 1px solid #3d5166; }
        .sidebar .logo span { color: #8e44ad; }
        .sidebar nav a { display: block; padding: 12px 20px; color: #bdc3c7; text-decoration: none; font-size: 14px; }
        .sidebar nav a:hover, .sidebar nav a.active { background: #8e44ad; color: white; }
        .sidebar .user-info { position: absolute; bottom: 0; width: 100%; padding: 14px 20px; border-top: 1px solid #3d5166; color: #bdc3c7; font-size: 12px; }
        .sidebar .user-info a { color: #e74c3c; text-decoration: none; }
        .main { margin-left: 220px; padding: 30px; max-width: 900px; }
        h1 { color: #2c3e50; font-size: 24px; margin-bottom: 6px; }
        .breadcrumb { color: #999; font-size: 13px; margin-bottom: 24px; }
        .card { background: white; border-radius: 8px; padding: 28px; box-shadow: 0 2px 6px rgba(0,0,0,.08); }
        label { display: block; font-size: 13px; color: #555; margin-bottom: 5px; margin-top: 16px; font-weight: bold; }
        input[type=text], textarea, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; font-family: Arial; }
        textarea { height: 280px; resize: vertical; }
        input:focus, textarea:focus, select:focus { outline: none; border-color: #8e44ad; }
        .actions { margin-top: 24px; display: flex; gap: 10px; }
        .btn-save { background: #8e44ad; color: white; padding: 10px 22px; border: none; border-radius: 6px; font-size: 14px; cursor: pointer; }
        .btn-save:hover { background: #732d91; }
        .btn-cancel { background: #bdc3c7; color: #2c3e50; padding: 10px 22px; border-radius: 6px; text-decoration: none; font-size: 14px; }
        .erro { background: #fde8e8; color: #c0392b; padding: 10px; border-radius: 6px; font-size: 13px; margin-bottom: 16px; }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="logo">📝 Blog<span>Admin</span></div>
    <nav>
        <a href="index.php">📊 Dashboard</a>
        <a href="post_novo.php" class="active">✏️ Novo Post</a>
        <a href="posts.php">📄 Todos os Posts</a>
        <a href="comentarios.php">💬 Comentários</a>
    </nav>
    <div class="user-info">
        👤 <?= htmlspecialchars($_SESSION['username']) ?><br>
        <a href="index.php?logout=1">Sair →</a>
    </div>
</div>
<div class="main">
    <h1>✏️ Novo Post</h1>
    <div class="breadcrumb">Blog Admin › <a href="index.php">Dashboard</a> › Novo Post</div>
    <div class="card">
        <?php if ($erro): ?>
        <div class="erro">⚠️ <?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>
        <form method="POST">
            <label>Título</label>
            <input type="text" name="titulo" placeholder="Título do post..." required>

            <label>Conteúdo</label>
            <textarea name="conteudo" placeholder="Escreve o conteúdo do post aqui..." required></textarea>

            <label>Estado</label>
            <select name="estado">
                <option value="rascunho">Rascunho</option>
                <option value="publicado">Publicado</option>
            </select>

            <div class="actions">
                <button type="submit" class="btn-save">💾 Guardar Post</button>
                <a href="index.php" class="btn-cancel">Cancelar</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
