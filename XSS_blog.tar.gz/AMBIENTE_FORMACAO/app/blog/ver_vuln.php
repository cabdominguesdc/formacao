<?php
ob_start();
$host = getenv('DB_HOST')     ?: 'mysql';
$db   = getenv('DB_DATABASE') ?: 'appdb';
$user = getenv('DB_USERNAME') ?: 'appuser';
$pass = getenv('DB_PASSWORD') ?: 'secret';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro de ligação.");
}

// ─── Submeter comentário (❌ SEM sanitização — vulnerável) ─────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_id'])) {
    $post_id  = (int)$_POST['post_id'];
    // ❌ VULNERÁVEL: sem htmlspecialchars no autor e mensagem
    $autor    = $_POST['autor'];
    $mensagem = $_POST['mensagem'];

    if ($autor && $mensagem) {
        $stmt = $pdo->prepare("INSERT INTO comentarios (post_id, autor, mensagem) VALUES (?, ?, ?)");
        $stmt->execute([$post_id, $autor, $mensagem]);
    }
    header("Location: " . $_SERVER['PHP_SELF'] . "?post=" . $post_id);
    exit;
}

// ─── Vista de post individual ──────────────────────────────────
if (isset($_GET['post'])) {
    $stmt = $pdo->prepare("SELECT p.*, u.username FROM posts p JOIN users u ON p.autor_id=u.id WHERE p.id=? AND p.estado='publicado'");
    $stmt->execute([(int)$_GET['post']]);
    $post = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($post) {
        $stmt = $pdo->prepare("SELECT * FROM comentarios WHERE post_id=? ORDER BY criado_em ASC");
        $stmt->execute([$post['id']]);
        $comentarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// ─── Pesquisa (❌ refletida sem sanitização — vulnerável) ───────
$pesquisa     = $_GET['q'] ?? '';
$resultados   = [];
if ($pesquisa !== '') {
    // ❌ VULNERÁVEL: parâmetro q usado diretamente no output
    $stmt = $pdo->prepare("SELECT p.*, u.username FROM posts p JOIN users u ON p.autor_id=u.id WHERE p.estado='publicado' AND (p.titulo LIKE ? OR p.conteudo LIKE ?)");
    $stmt->execute(["%$pesquisa%", "%$pesquisa%"]);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ─── Lista de posts publicados ────────────────────────────────
$posts = $pdo->query("SELECT p.*, u.username, (SELECT COUNT(*) FROM comentarios c WHERE c.post_id=p.id) AS total_coms FROM posts p JOIN users u ON p.autor_id=u.id WHERE p.estado='publicado' ORDER BY p.criado_em DESC")->fetchAll(PDO::FETCH_ASSOC);

ob_end_flush();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>O Meu Blog</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Georgia, serif; background: #f9f9f9; color: #333; }

        /* Header */
        header { background: #2c3e50; color: white; padding: 0; }
        .header-inner { max-width: 1100px; margin: 0 auto; padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; }
        .header-inner h1 { font-size: 26px; letter-spacing: 1px; }
        .header-inner h1 span { color: #8e44ad; }

        /* Barra de pesquisa */
        .search-bar { background: #34495e; padding: 12px 0; }
        .search-inner { max-width: 1100px; margin: 0 auto; padding: 0 30px; display: flex; gap: 10px; }
        .search-inner input { flex: 1; padding: 8px 14px; border: none; border-radius: 4px; font-size: 14px; }
        .search-inner button { padding: 8px 18px; background: #8e44ad; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; }

        /* Layout */
        .container { max-width: 1100px; margin: 30px auto; padding: 0 30px; display: grid; grid-template-columns: 1fr 300px; gap: 30px; }

        /* Posts */
        .post-card { background: white; border-radius: 8px; padding: 28px; margin-bottom: 22px; box-shadow: 0 2px 6px rgba(0,0,0,.07); }
        .post-card h2 { font-size: 22px; margin-bottom: 8px; }
        .post-card h2 a { color: #2c3e50; text-decoration: none; }
        .post-card h2 a:hover { color: #8e44ad; }
        .post-meta { font-size: 12px; color: #999; margin-bottom: 14px; font-family: Arial; }
        .post-meta span { margin-right: 14px; }
        .post-body { line-height: 1.7; color: #555; font-size: 15px; }
        .read-more { display: inline-block; margin-top: 14px; color: #8e44ad; text-decoration: none; font-family: Arial; font-size: 13px; }

        /* Comentários */
        .comments-section { margin-top: 30px; }
        .comments-section h3 { font-size: 18px; color: #2c3e50; margin-bottom: 16px; font-family: Arial; border-bottom: 2px solid #8e44ad; padding-bottom: 8px; }
        .comentario { background: #f8f9fa; border-radius: 6px; padding: 14px; margin-bottom: 12px; border-left: 3px solid #8e44ad; }
        .comentario .com-autor { font-weight: bold; font-size: 13px; color: #2c3e50; font-family: Arial; }
        .comentario .com-data  { font-size: 11px; color: #aaa; margin-left: 8px; font-family: Arial; }
        /* ❌ VULNERÁVEL: .com-texto renderiza HTML sem escape */
        .comentario .com-texto { margin-top: 6px; line-height: 1.6; font-size: 14px; }

        /* Formulário de comentário */
        .comment-form { background: white; border-radius: 8px; padding: 22px; margin-top: 20px; box-shadow: 0 2px 6px rgba(0,0,0,.07); }
        .comment-form h4 { font-size: 16px; color: #2c3e50; margin-bottom: 14px; font-family: Arial; }
        .comment-form label { display: block; font-size: 13px; color: #555; margin-bottom: 4px; margin-top: 12px; font-family: Arial; }
        .comment-form input, .comment-form textarea { width: 100%; padding: 9px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px; font-family: Arial; }
        .comment-form textarea { height: 90px; resize: vertical; }
        .comment-form button { margin-top: 14px; padding: 9px 20px; background: #8e44ad; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; font-family: Arial; }
        .comment-form button:hover { background: #732d91; }

        /* Sidebar */
        .sidebar-widget { background: white; border-radius: 8px; padding: 20px; margin-bottom: 22px; box-shadow: 0 2px 6px rgba(0,0,0,.07); }
        .sidebar-widget h3 { font-size: 15px; color: #2c3e50; margin-bottom: 14px; font-family: Arial; border-bottom: 2px solid #8e44ad; padding-bottom: 6px; }
        .sidebar-widget ul { list-style: none; }
        .sidebar-widget ul li { padding: 7px 0; border-bottom: 1px solid #f0f0f0; font-family: Arial; font-size: 13px; }
        .sidebar-widget ul li:last-child { border: none; }
        .sidebar-widget ul li a { color: #555; text-decoration: none; }
        .sidebar-widget ul li a:hover { color: #8e44ad; }

        /* Pesquisa resultado */
        .search-resultado { background: #fff8e1; border-left: 4px solid #f39c12; padding: 10px 14px; margin-bottom: 8px; border-radius: 4px; font-family: Arial; font-size: 14px; }
        .search-resultado a { color: #2c3e50; text-decoration: none; font-weight: bold; }
        /* ❌ VULNERÁVEL: search-info reflete o termo sem escape */
        .search-info { background: #eaf0fb; padding: 10px 16px; border-radius: 6px; margin-bottom: 18px; font-family: Arial; font-size: 14px; color: #2980b9; }

        /* Back link */
        .back { font-family: Arial; font-size: 13px; margin-bottom: 20px; }
        .back a { color: #8e44ad; text-decoration: none; }

        footer { background: #2c3e50; color: #bdc3c7; text-align: center; padding: 18px; font-family: Arial; font-size: 13px; margin-top: 40px; }
    </style>
</head>
<body>

<header>
    <div class="header-inner">
        <h1>📝 O Meu <span>Blog</span></h1>
        <a href="?logout=1" style="color:#bdc3c7;font-family:Arial;font-size:13px;text-decoration:none">Admin →</a>
    </div>
</header>

<div class="search-bar">
    <div class="search-inner">
        <form method="GET" style="display:flex;gap:10px;width:100%">
            <input type="text" name="q" placeholder="Pesquisar posts..."
                   value="<?= htmlspecialchars($pesquisa) // ✅ este campo está correto ?>">
            <button type="submit">🔍 Pesquisar</button>
        </form>
    </div>
</div>

<div class="container">
<div class="content">

<?php if (isset($post) && $post): ?>
    <!-- ══════════════════════════════════════════════
         VISTA DE POST INDIVIDUAL + COMENTÁRIOS
         ══════════════════════════════════════════════ -->
    <div class="back"><a href="index.php">← Voltar ao blog</a></div>

    <div class="post-card">
        <!-- ✅ título sanitizado -->
        <h2><?= htmlspecialchars($post['titulo']) ?></h2>
        <div class="post-meta">
            <span>✍️ <?= htmlspecialchars($post['username']) ?></span>
            <span>📅 <?= date('d/m/Y', strtotime($post['criado_em'])) ?></span>
        </div>
        <!-- ❌ VULNERÁVEL: conteúdo do post sem sanitização -->
        <div class="post-body"><?= $post['conteudo'] ?></div>
    </div>

    <!-- Comentários -->
    <div class="comments-section">
        <h3>💬 Comentários (<?= count($comentarios) ?>)</h3>

        <?php if (empty($comentarios)): ?>
            <p style="color:#999;font-family:Arial;font-size:14px">Sem comentários ainda. Sê o primeiro!</p>
        <?php endif; ?>

        <?php foreach ($comentarios as $c): ?>
        <div class="comentario">
            <!-- ❌ VULNERÁVEL: autor e mensagem sem htmlspecialchars -->
            <span class="com-autor"><?= $c['autor'] ?></span>
            <span class="com-data"><?= date('d/m/Y H:i', strtotime($c['criado_em'])) ?></span>
            <div class="com-texto"><?= $c['mensagem'] ?></div>
        </div>
        <?php endforeach; ?>

        <!-- Formulário de comentário -->
        <div class="comment-form">
            <h4>Deixa um comentário</h4>
            <form method="POST">
                <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                <label>Nome</label>
                <input type="text" name="autor" placeholder="O teu nome..." required>
                <label>Comentário</label>
                <textarea name="mensagem" placeholder="Escreve aqui..." required></textarea>
                <button type="submit">Publicar Comentário</button>
            </form>
        </div>
    </div>

<?php elseif ($pesquisa !== ''): ?>
    <!-- ══════════════════════════════════════════════
         RESULTADOS DE PESQUISA
         ══════════════════════════════════════════════ -->

    <!-- ❌ VULNERÁVEL: $pesquisa refletida sem sanitização -->
    <div class="search-info">
        🔍 Resultados para: <strong><?= $pesquisa ?></strong>
        (<?= count($resultados) ?> encontrado<?= count($resultados) != 1 ? 's' : '' ?>)
    </div>

    <?php if (empty($resultados)): ?>
        <div class="post-card">
            <p style="color:#999;font-family:Arial">Nenhum post encontrado para "<?= $pesquisa ?>".</p>
        </div>
    <?php endif; ?>

    <?php foreach ($resultados as $p): ?>
    <div class="search-resultado">
        <a href="?post=<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></a>
        <span style="color:#999;margin-left:8px;font-size:12px"><?= date('d/m/Y', strtotime($p['criado_em'])) ?></span>
    </div>
    <?php endforeach; ?>

<?php else: ?>
    <!-- ══════════════════════════════════════════════
         LISTA DE POSTS
         ══════════════════════════════════════════════ -->
    <?php if (empty($posts)): ?>
    <div class="post-card">
        <p style="color:#999;font-family:Arial;text-align:center;padding:20px">
            Ainda não há posts publicados.
        </p>
    </div>
    <?php endif; ?>

    <?php foreach ($posts as $p): ?>
    <div class="post-card">
        <h2><a href="?post=<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></a></h2>
        <div class="post-meta">
            <span>✍️ <?= htmlspecialchars($p['username']) ?></span>
            <span>📅 <?= date('d/m/Y', strtotime($p['criado_em'])) ?></span>
            <span>💬 <?= $p['total_coms'] ?> comentário<?= $p['total_coms'] != 1 ? 's' : '' ?></span>
        </div>
        <!-- ❌ VULNERÁVEL: conteúdo sem sanitização -->
        <div class="post-body"><?= $p['conteudo'] ?></div>
        <a href="?post=<?= $p['id'] ?>" class="read-more">Ler mais →</a>
    </div>
    <?php endforeach; ?>

<?php endif; ?>

</div>

<!-- Sidebar -->
<aside>
    <div class="sidebar-widget">
        <h3>📄 Posts Recentes</h3>
        <ul>
            <?php foreach (array_slice($posts, 0, 5) as $p): ?>
            <li><a href="?post=<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></a></li>
            <?php endforeach; ?>
            <?php if (empty($posts)): ?>
            <li style="color:#999">Sem posts ainda.</li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="sidebar-widget">
        <h3>🔗 Links</h3>
        <ul>
            <li><a href="/admin/login.php">⚙️ Área Admin</a></li>
            <li><a href="/xss.php">🧪 Demo XSS Refletido</a></li>
            <li><a href="/xss_stored.php">🧪 Demo XSS Armazenado</a></li>
            <li><a href="/xss_dom.php">🧪 Demo XSS DOM</a></li>
        </ul>
    </div>
</aside>

</div>

<footer>
    Blog de Formação — Ambiente de Testes | Não usar em produção
</footer>

</body>
</html>
