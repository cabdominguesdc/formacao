<?php require 'auth.php'; ?>
<?php
if (isset($_GET['apagar'])) {
    $stmt = $pdo->prepare("DELETE FROM comentarios WHERE id = ?");
    $stmt->execute([(int)$_GET['apagar']]);
    header('Location: comentarios.php?msg=apagado');
    exit;
}

$comentarios = $pdo->query("
    SELECT c.*, p.titulo
    FROM comentarios c
    JOIN posts p ON c.post_id = p.id
    ORDER BY c.criado_em DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Comentários – Blog Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; background: #f0f2f5; }
        .sidebar { width: 220px; background: #2c3e50; min-height: 100vh; position: fixed; top: 0; left: 0; }
        .sidebar .logo { padding: 24px 20px; color: white; font-size: 18px; font-weight: bold; border-bottom: 1px solid #3d5166; }
        .sidebar .logo span { color: #8e44ad; }
        .sidebar nav a { display: block; padding: 12px 20px; color: #bdc3c7; text-decoration: none; font-size: 14px; }
        .sidebar nav a:hover, .sidebar nav a.active { background: #8e44ad; color: white; }
        .sidebar .user-info { position: absolute; bottom: 0; width: 100%; padding: 14px 20px; border-top: 1px solid #3d5166; color: #bdc3c7; font-size: 12px; }
        .sidebar .user-info a { color: #e74c3c; text-decoration: none; }
        .main { margin-left: 220px; padding: 30px; }
        h1 { color: #2c3e50; font-size: 24px; margin-bottom: 6px; }
        .breadcrumb { color: #999; font-size: 13px; margin-bottom: 24px; }
        .section { background: white; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,.08); }
        .section-header { padding: 16px 20px; border-bottom: 1px solid #eee; }
        .section-header h2 { font-size: 16px; color: #2c3e50; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8f9fa; padding: 10px 16px; text-align: left; font-size: 12px; color: #666; text-transform: uppercase; border-bottom: 1px solid #eee; }
        td { padding: 12px 16px; font-size: 14px; border-bottom: 1px solid #f5f5f5; vertical-align: top; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #fafafa; }
        .btn { padding: 5px 12px; border-radius: 4px; font-size: 12px; text-decoration: none; }
        .btn-del { background: #e74c3c; color: white; }
        .mensagem { max-width: 400px; word-break: break-word; }
        .alert { background: #d5f5e3; color: #27ae60; padding: 10px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 13px; }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="logo">📝 Blog<span>Admin</span></div>
    <nav>
        <a href="index.php">📊 Dashboard</a>
        <a href="post_novo.php">✏️ Novo Post</a>
        <a href="posts.php">📄 Todos os Posts</a>
        <a href="comentarios.php" class="active">💬 Comentários</a>
    </nav>
    <div class="user-info">
        👤 <?= htmlspecialchars($_SESSION['username']) ?><br>
        <a href="index.php?logout=1">Sair →</a>
    </div>
</div>
<div class="main">
    <h1>💬 Comentários</h1>
    <div class="breadcrumb">Blog Admin › <a href="index.php">Dashboard</a> › Comentários</div>

    <?php if (isset($_GET['msg'])): ?>
    <div class="alert">✅ Comentário apagado.</div>
    <?php endif; ?>

    <div class="section">
        <div class="section-header">
            <h2>Todos os comentários (<?= count($comentarios) ?>)</h2>
        </div>
        <table>
            <tr><th>#</th><th>Autor</th><th>Post</th><th>Mensagem</th><th>Data</th><th>Ação</th></tr>
            <?php if (empty($comentarios)): ?>
            <tr><td colspan="6" style="text-align:center;color:#999;padding:24px">Sem comentários.</td></tr>
            <?php endif; ?>
            <?php foreach ($comentarios as $c): ?>
            <tr>
                <td><?= $c['id'] ?></td>
                <td><?= htmlspecialchars($c['autor']) ?></td>
                <td><?= htmlspecialchars($c['titulo']) ?></td>
                <td class="mensagem"><?= htmlspecialchars(mb_strimwidth($c['mensagem'], 0, 80, '...')) ?></td>
                <td><?= date('d/m/Y H:i', strtotime($c['criado_em'])) ?></td>
                <td><a href="?apagar=<?= $c['id'] ?>" class="btn btn-del" onclick="return confirm('Apagar?')">Apagar</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
</body>
</html>
