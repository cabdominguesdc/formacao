<?php
ob_start();
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = getenv('DB_HOST')     ?: 'mysql';
    $db   = getenv('DB_DATABASE') ?: 'appdb';
    $user = getenv('DB_USERNAME') ?: 'appuser';
    $pass = getenv('DB_PASSWORD') ?: 'secret';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([trim($_POST['username'])]);
        $u = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($u && password_verify($_POST['password'], $u['password'])) {
            $_SESSION['user_id']  = $u['id'];
            $_SESSION['username'] = $u['username'];
            $_SESSION['role']     = $u['role'];
            header('Location: index.php');
            exit;
        } else {
            $erro = 'Utilizador ou password incorretos.';
        }
    } catch (PDOException $e) {
        $erro = 'Erro de ligação à base de dados.';
    }
}
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Login – Blog Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #1a1a2e; display: flex; align-items: center; justify-content: center; min-height: 100vh; font-family: Arial, sans-serif; }
        .card { background: white; border-radius: 10px; padding: 40px; width: 360px; box-shadow: 0 10px 30px rgba(0,0,0,0.4); }
        .card h1 { text-align: center; color: #2c3e50; margin-bottom: 6px; font-size: 22px; }
        .card p.sub { text-align: center; color: #999; font-size: 13px; margin-bottom: 24px; }
        label { display: block; font-size: 13px; color: #555; margin-bottom: 4px; margin-top: 14px; }
        input[type=text], input[type=password] { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; }
        input:focus { outline: none; border-color: #8e44ad; }
        button { width: 100%; margin-top: 22px; padding: 11px; background: #8e44ad; color: white; border: none; border-radius: 6px; font-size: 15px; cursor: pointer; }
        button:hover { background: #732d91; }
        .erro { background: #fde8e8; color: #c0392b; padding: 10px; border-radius: 6px; font-size: 13px; margin-top: 16px; text-align: center; }
        .lock { font-size: 40px; text-align: center; margin-bottom: 10px; }
    </style>
</head>
<body>
<div class="card">
    <div class="lock">🔐</div>
    <h1>Blog Admin</h1>
    <p class="sub">Introduz as tuas credenciais</p>
    <form method="POST">
        <label>Utilizador</label>
        <input type="text" name="username" placeholder="admin" autofocus required>
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required>
        <button type="submit">Entrar</button>
    </form>
    <?php if ($erro): ?>
        <div class="erro">⚠️ <?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>
</div>
</body>
</html>
