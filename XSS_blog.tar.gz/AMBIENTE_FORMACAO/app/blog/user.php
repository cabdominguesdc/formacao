<?php require 'auth.php'; ?>
<?php
// ─── Criar tabela de comentários privados se não existir ──────
$pdo->exec("
    CREATE TABLE IF NOT EXISTS comentarios_privados (
        id        INT AUTO_INCREMENT PRIMARY KEY,
        post_id   INT          NOT NULL,
        user_id   INT          NOT NULL,
        mensagem  TEXT         NOT NULL,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (post_id)  REFERENCES posts(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id)  REFERENCES users(id) ON DELETE CASCADE
    )
");

// ─── Submeter comentário privado (❌ SEM sanitização no output) ─
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_id'])) {
    $post_id  = (int)$_POST['post_id'];
    $mensagem = $_POST['mensagem'];
    if ($mensagem) {
        $stmt = $pdo->prepare("INSERT INTO comentarios_privados (post_id, user_id, mensagem) VALUES (?, ?, ?)");
        $stmt->execute([$post_id, $_SESSION['user_id'], $mensagem]);
    }
    header("Location: index.php?post=" . $post_id);
    exit;
}

// ─── Apagar comentário privado (só do próprio utilizador) ─────
if (isset($_GET['apagar']) && isset($_GET['post'])) {
    $stmt = $pdo->prepare("DELETE FROM comentarios_privados WHERE id=? AND user_id=?");
    $stmt->execute([(int)$_GET['apagar'], $_SESSION['user_id']]);
    header("Location: index.php?post=" . (int)$_GET['post']);
    exit;
}

// ─── Logout ───────────────────────────────────────────────────
if (isset($_GET['logout'])) { session_destroy(); header('Location: login.php'); exit; }

// ─── Vista de post individual ─────────────────────────────────
$post        = null;
$coms_priv   = [];
$coms_pub    = [];

if (isset($_GET['post'])) {
    $stmt = $pdo->prepare("SELECT p.*, u.username FROM posts p JOIN users u ON p.autor_id=u.id WHERE p.id=? AND p.estado='publicado'");
    $stmt->execute([(int)$_GET['post']]);
    $post = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($post) {
        // Comentários públicos
        $stmt = $pdo->prepare("SELECT * FROM comentarios WHERE post_id=? ORDER BY criado_em ASC");
        $stmt->execute([$post['id']]);
        $coms_pub = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Comentários privados — só do utilizador autenticado
        $stmt = $pdo->prepare("SELECT * FROM comentarios_privados WHERE post_id=? AND user_id=? ORDER BY criado_em ASC");
        $stmt->execute([$post['id'], $_SESSION['user_id']]);
        $coms_priv = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// ─── Lista de posts publicados ────────────────────────────────
$posts = $pdo->query("
    SELECT p.*, u.username,
        (SELECT COUNT(*) FROM comentarios c WHERE c.post_id=p.id) AS total_pub,
        (SELECT COUNT(*) FROM comentarios_privados cp WHERE cp.post_id=p.id AND cp.user_id={$_SESSION['user_id']}) AS total_priv
    FROM posts p JOIN users u ON p.autor_id=u.id
    WHERE p.estado='publicado'
    ORDER BY p.criado_em DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Área de Utilizadores – Blog</title>
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:Georgia,serif;background:#f0f4f8;color:#333}
        header{background:#1a252f;color:white;padding:0}
        .header-inner{max-width:1100px;margin:0 auto;padding:16px 30px;display:flex;justify-content:space-between;align-items:center}
        .header-inner h1{font-size:22px}.header-inner h1 span{color:#3498db}
        .user-bar{background:#2c3e50;padding:8px 0}
        .user-bar-inner{max-width:1100px;margin:0 auto;padding:0 30px;display:flex;justify-content:space-between;align-items:center;font-family:Arial;font-size:13px;color:#bdc3c7}
        .user-bar-inner a{color:#e74c3c;text-decoration:none;margin-left:16px}
        .container{max-width:1100px;margin:28px auto;padding:0 30px;display:grid;grid-template-columns:1fr 280px;gap:26px}
        /* Post card */
        .post-card{background:white;border-radius:8px;padding:26px;margin-bottom:20px;box-shadow:0 2px 6px rgba(0,0,0,.07)}
        .post-card h2{font-size:20px;margin-bottom:8px}
        .post-card h2 a{color:#1a252f;text-decoration:none}.post-card h2 a:hover{color:#3498db}
        .post-meta{font-size:12px;color:#999;margin-bottom:12px;font-family:Arial}
        .post-meta span{margin-right:12px}
        .post-body{line-height:1.75;color:#555;font-size:15px}
        .read-more{display:inline-block;margin-top:12px;color:#3498db;text-decoration:none;font-family:Arial;font-size:13px}
        /* Badges contadores */
        .badge-pub{background:#d5f5e3;color:#27ae60;padding:2px 8px;border-radius:10px;font-size:11px;font-family:Arial}
        .badge-priv{background:#eaf0fb;color:#2980b9;padding:2px 8px;border-radius:10px;font-size:11px;font-family:Arial}
        /* Comentários */
        .section-title{font-size:16px;color:#1a252f;margin:24px 0 12px;font-family:Arial;border-bottom:2px solid #3498db;padding-bottom:6px}
        .com-pub{background:#f8f9fa;border-left:3px solid #27ae60;border-radius:5px;padding:12px;margin-bottom:10px}
        .com-priv{background:#eaf4fb;border-left:3px solid #3498db;border-radius:5px;padding:12px;margin-bottom:10px;position:relative}
        .com-priv .priv-label{position:absolute;top:10px;right:12px;background:#3498db;color:white;font-size:10px;padding:2px 7px;border-radius:8px;font-family:Arial}
        .com-autor{font-weight:bold;font-size:13px;color:#2c3e50;font-family:Arial}
        .com-data{font-size:11px;color:#aaa;margin-left:8px;font-family:Arial}
        /* ❌ VULNERÁVEL: .com-texto renderiza HTML sem escape */
        .com-texto{margin-top:6px;line-height:1.6;font-size:14px}
        .btn-del{font-size:11px;color:#e74c3c;text-decoration:none;font-family:Arial;margin-left:8px}
        /* Formulário */
        .comment-form{background:white;border-radius:8px;padding:20px;margin-top:18px;box-shadow:0 2px 6px rgba(0,0,0,.07);border-top:3px solid #3498db}
        .comment-form h4{font-size:15px;color:#1a252f;margin-bottom:12px;font-family:Arial}
        .comment-form .priv-notice{background:#eaf4fb;padding:8px 12px;border-radius:5px;font-size:12px;color:#2980b9;margin-bottom:12px;font-family:Arial}
        .comment-form textarea{width:100%;padding:9px;border:1px solid #ddd;border-radius:5px;font-size:14px;font-family:Arial;height:90px;resize:vertical}
        .comment-form button{margin-top:10px;padding:9px 20px;background:#3498db;color:white;border:none;border-radius:5px;cursor:pointer;font-size:14px;font-family:Arial}
        .comment-form button:hover{background:#2980b9}
        /* Sidebar */
        .sidebar-widget{background:white;border-radius:8px;padding:18px;margin-bottom:20px;box-shadow:0 2px 6px rgba(0,0,0,.07)}
        .sidebar-widget h3{font-size:14px;color:#1a252f;margin-bottom:12px;font-family:Arial;border-bottom:2px solid #3498db;padding-bottom:5px}
        .sidebar-widget ul{list-style:none}
        .sidebar-widget ul li{padding:7px 0;border-bottom:1px solid #f0f0f0;font-family:Arial;font-size:13px}
        .sidebar-widget ul li:last-child{border:none}
        .sidebar-widget ul li a{color:#555;text-decoration:none}.sidebar-widget ul li a:hover{color:#3498db}
        .back{font-family:Arial;font-size:13px;margin-bottom:18px}
        .back a{color:#3498db;text-decoration:none}
        footer{background:#1a252f;color:#bdc3c7;text-align:center;padding:16px;font-family:Arial;font-size:13px;margin-top:40px}
        .aviso{background:#fff3cd;border-left:4px solid #f39c12;padding:10px 14px;font-family:Arial;font-size:13px;margin-bottom:20px;border-radius:4px}
    </style>
</head>
<body>

<header>
    <div class="header-inner">
        <h1>📝 Blog <span>Privado</span></h1>
        <span style="font-family:Arial;font-size:13px;color:#bdc3c7">Área restrita</span>
    </div>
</header>
<div class="user-bar">
    <div class="user-bar-inner">
        <span>👤 Sessão iniciada como <strong><?= htmlspecialchars($_SESSION['username']) ?></strong> (<?= $_SESSION['role'] ?>)</span>
        <span>
            <a href="/blog/">Blog público</a>
            <a href="?logout=1">Sair</a>
        </span>
    </div>
</div>

<div class="container">
<div class="content">

<?php if ($post): ?>
    <!-- ═══════════════════════════════════════
         VISTA DE POST INDIVIDUAL
         ═══════════════════════════════════════ -->
    <div class="back"><a href="index.php">← Voltar</a></div>

    <div class="aviso">
        ⚠️ Esta página é <strong>vulnerável a XSS</strong> — os comentários privados são renderizados sem sanitização. Apenas para formação.
    </div>

    <div class="post-card">
        <h2><?= htmlspecialchars($post['titulo']) ?></h2>
        <div class="post-meta">
            <span>✍️ <?= htmlspecialchars($post['username']) ?></span>
            <span>📅 <?= date('d/m/Y', strtotime($post['criado_em'])) ?></span>
        </div>
        <!-- ❌ VULNERÁVEL: conteúdo do post sem escape -->
        <div class="post-body"><?= $post['conteudo'] ?></div>
    </div>

    <!-- Comentários públicos -->
    <div class="section-title">💬 Comentários públicos (<?= count($coms_pub) ?>)</div>
    <?php if (empty($coms_pub)): ?>
        <p style="color:#999;font-family:Arial;font-size:14px;margin-bottom:16px">Sem comentários públicos.</p>
    <?php endif; ?>
    <?php foreach ($coms_pub as $c): ?>
    <div class="com-pub">
        <!-- ❌ VULNERÁVEL: sem htmlspecialchars -->
        <span class="com-autor"><?= $c['autor'] ?></span>
        <span class="com-data"><?= date('d/m/Y H:i', strtotime($c['criado_em'])) ?></span>
        <div class="com-texto"><?= $c['mensagem'] ?></div>
    </div>
    <?php endforeach; ?>

    <!-- Comentários privados -->
    <div class="section-title">🔒 Os meus comentários privados (<?= count($coms_priv) ?>)</div>
    <?php if (empty($coms_priv)): ?>
        <p style="color:#999;font-family:Arial;font-size:14px;margin-bottom:16px">Ainda não tens comentários privados neste post.</p>
    <?php endif; ?>
    <?php foreach ($coms_priv as $c): ?>
    <div class="com-priv">
        <span class="priv-label">🔒 PRIVADO</span>
        <span class="com-autor"><?= htmlspecialchars($_SESSION['username']) ?></span>
        <span class="com-data"><?= date('d/m/Y H:i', strtotime($c['criado_em'])) ?></span>
        <a href="?apagar=<?= $c['id'] ?>&post=<?= $post['id'] ?>" class="btn-del"
           onclick="return confirm('Apagar?')">✕ apagar</a>
        <!-- ❌ VULNERÁVEL: mensagem privada sem sanitização -->
        <div class="com-texto"><?= $c['mensagem'] ?></div>
    </div>
    <?php endforeach; ?>

    <!-- Formulário de comentário privado -->
    <div class="comment-form">
        <h4>✏️ Adicionar comentário privado</h4>
        <div class="priv-notice">🔒 Este comentário é <strong>apenas visível para ti</strong>. Não é mostrado no blog público.</div>
        <form method="POST">
            <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
            <textarea name="mensagem" placeholder="Escreve o teu comentário privado..." required></textarea>
            <button type="submit">💾 Guardar comentário privado</button>
        </form>
    </div>

<?php else: ?>
    <!-- ═══════════════════════════════════════
         LISTA DE POSTS
         ═══════════════════════════════════════ -->
    <div class="aviso">
        ⚠️ <strong>Ambiente de formação.</strong> Os comentários privados são vulneráveis a XSS armazenado.
    </div>

    <?php if (empty($posts)): ?>
    <div class="post-card"><p style="color:#999;font-family:Arial;text-align:center;padding:20px">Sem posts publicados.</p></div>
    <?php endif; ?>

    <?php foreach ($posts as $p): ?>
    <div class="post-card">
        <h2><a href="?post=<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></a></h2>
        <div class="post-meta">
            <span>✍️ <?= htmlspecialchars($p['username']) ?></span>
            <span>📅 <?= date('d/m/Y', strtotime($p['criado_em'])) ?></span>
            <span><span class="badge-pub">💬 <?= $p['total_pub'] ?> públicos</span></span>
            <span><span class="badge-priv">🔒 <?= $p['total_priv'] ?> privados</span></span>
        </div>
        <!-- ❌ VULNERÁVEL -->
        <div class="post-body"><?= $p['conteudo'] ?></div>
        <a href="?post=<?= $p['id'] ?>" class="read-more">Ver post e comentar →</a>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

</div>

<!-- Sidebar -->
<aside>
    <div class="sidebar-widget">
        <h3>📄 Posts</h3>
        <ul>
            <?php foreach (array_slice($posts, 0, 6) as $p): ?>
            <li>
                <a href="?post=<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></a>
                <?php if ($p['total_priv'] > 0): ?>
                <span class="badge-priv">🔒 <?= $p['total_priv'] ?></span>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="sidebar-widget">
        <h3>🔗 Navegação</h3>
        <ul>
            <li><a href="/blog/">🌐 Blog público</a></li>
            <li><a href="/admin/login.php">⚙️ Admin</a></li>
            <li><a href="?logout=1">🚪 Sair</a></li>
        </ul>
    </div>
    <div class="sidebar-widget" style="background:#fff8e1;border-left:3px solid #f39c12">
        <h3 style="color:#e67e22">🎓 Vetores XSS</h3>
        <ul>
            <li style="color:#555">Comentário privado com payload</li>
            <li style="color:#555">Conteúdo do post (admin)</li>
            <li style="color:#555">Comentários públicos do blog</li>
        </ul>
    </div>
</aside>

</div>
<footer>Área Privada – Ambiente de Formação | Não usar em produção</footer>
</body>
</html>
