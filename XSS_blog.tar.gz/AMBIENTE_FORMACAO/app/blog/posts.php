<?php require 'auth.php'; ?>
<?php
// ─── Ações ────────────────────────────────────────────────────
if (isset($_GET['apagar'])) {
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([(int)$_GET['apagar']]);
    header('Location: posts.php?msg=apagado');
    exit;
}

if (isset($_GET['toggle'])) {
    $stmt = $pdo->prepare("UPDATE posts SET estado = IF(estado='publicado','rascunho','publicado') WHERE id = ?");
    $stmt->execute([(int)$_GET['toggle']]);
    header('Location: posts.php');
    exit;
}

$posts = $pdo->query("
    SELECT p.*, u.username,
           (SELECT COUNT(*) FROM comentarios c WHERE c.post_id = p.id) AS total_comentarios
    FROM posts p
    JOIN users u ON p.autor_id = u.id
    ORDER BY p.criado_em DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Posts – Blog Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; background: #f0f2f5; }
        .sidebar { width: 220px; background: #2c3e50; min-height: 100vh; position: fixed; top: 0; left: 0; }
        .sidebar .logo { padding: 24px 20px; color: white; font-size: 18px; font-weight: bold; border-bottom: 1px solid #3d5166; }
        .sidebar .logo span { color: #8e44ad; }
        .sidebar nav a { display: block; padding: 12px 20px; color: #bdc3c7; text-decoration: none; font-size: 14px; }
        .sidebar nav a:hover, .sidebar nav a.active { background: #8e44ad; color: white; }
        .sidebar .user-info { position: absolute; bottom: 0; width: 100%; padding: 14px 20px; border-top: 1px solid #3d5166; color: #bdc3c7; font-size: 12px; }
        .sidebar .user-info a { color: #e74c3c; text-decoration: none; }
        .main { margin-left: 220px; padding: 30px; }
        h1 { color: #2c3e50; font-size: 24px; margin-bottom: 6px; }
        .breadcrumb { color: #999; font-size: 13px; margin-bottom: 24px; }
        .section { background: white; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,.08); }
        .section-header { padding: 16px 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }
        .section-header h2 { font-size: 16px; color: #2c3e50; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8f9fa; padding: 10px 16px; text-align: left; font-size: 12px; color: #666; text-transform: uppercase; border-bottom: 1px solid #eee; }
        td { padding: 12px 16px; font-size: 14px; border-bottom: 1px solid #f5f5f5; vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #fafafa; }
        .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .badge.pub { background: #d5f5e3; color: #27ae60; }
        .badge.ras { background: #fdebd0; color: #f39c12; }
        .btn { padding: 5px 12px; border-radius: 4px; font-size: 12px; text-decoration: none; border: none; cursor: pointer; display: inline-block; }
        .btn-edit { background: #3498db; color: white; }
        .btn-del  { background: #e74c3c; color: white; }
        .btn-tog  { background: #f39c12; color: white; }
        .btn-new  { background: #8e44ad; color: white; padding: 8px 16px; font-size: 13px; border-radius: 6px; text-decoration: none; }
        .btn:hover { opacity: .85; }
        .alert { background: #d5f5e3; color: #27ae60; padding: 10px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 13px; }
        .com-count { background: #eaf0fb; color: #2980b9; padding: 2px 8px; border-radius: 10px; font-size: 12px; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="logo">📝 Blog<span>Admin</span></div>
    <nav>
        <a href="index.php">📊 Dashboard</a>
        <a href="post_novo.php">✏️ Novo Post</a>
        <a href="posts.php" class="active">📄 Todos os Posts</a>
        <a href="comentarios.php">💬 Comentários</a>
    </nav>
    <div class="user-info">
        👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= $_SESSION['role'] ?>)<br>
        <a href="index.php?logout=1">Sair →</a>
    </div>
</div>

<div class="main">
    <h1>📄 Todos os Posts</h1>
    <div class="breadcrumb">Blog Admin › <a href="index.php">Dashboard</a> › Posts</div>

    <?php if (isset($_GET['msg'])): ?>
    <div class="alert">✅ Post apagado com sucesso.</div>
    <?php endif; ?>

    <div class="section">
        <div class="section-header">
            <h2>Posts (<?= count($posts) ?>)</h2>
            <a href="post_novo.php" class="btn-new">+ Novo Post</a>
        </div>
        <table>
            <tr>
                <th>#</th>
                <th>Título</th>
                <th>Autor</th>
                <th>Estado</th>
                <th>Comentários</th>
                <th>Data</th>
                <th>Ações</th>
            </tr>
            <?php if (empty($posts)): ?>
            <tr>
                <td colspan="7" style="text-align:center;color:#999;padding:30px">
                    Ainda não há posts. <a href="post_novo.php">Cria o primeiro!</a>
                </td>
            </tr>
            <?php endif; ?>
            <?php foreach ($posts as $p): ?>
            <tr>
                <td><?= $p['id'] ?></td>
                <td><?= htmlspecialchars($p['titulo']) ?></td>
                <td><?= htmlspecialchars($p['username']) ?></td>
                <td>
                    <span class="badge <?= $p['estado'] === 'publicado' ? 'pub' : 'ras' ?>">
                        <?= $p['estado'] ?>
                    </span>
                </td>
                <td><span class="com-count">💬 <?= $p['total_comentarios'] ?></span></td>
                <td><?= date('d/m/Y H:i', strtotime($p['criado_em'])) ?></td>
                <td>
                    <a href="post_editar.php?id=<?= $p['id'] ?>" class="btn btn-edit">Editar</a>
                    <a href="?toggle=<?= $p['id'] ?>" class="btn btn-tog">
                        <?= $p['estado'] === 'publicado' ? 'Despublicar' : 'Publicar' ?>
                    </a>
                    <a href="?apagar=<?= $p['id'] ?>" class="btn btn-del"
                       onclick="return confirm('Apagar este post e os seus comentários?')">Apagar</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>

</body>
</html>
