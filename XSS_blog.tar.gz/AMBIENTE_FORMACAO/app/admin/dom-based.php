<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Demo XSS baseado em DOM – Formação</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 40px auto; padding: 0 20px; background: #f5f5f5; }
        h1 { color: #16a085; }
        .box { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .aviso { background: #fff3cd; border-left: 4px solid #f39c12; padding: 10px 15px; margin-bottom: 20px; }
        input[type=text] { width: 70%; padding: 8px; font-size: 14px; }
        button { padding: 8px 16px; background: #16a085; color: white; border: none; cursor: pointer; font-size: 14px; border-radius: 4px; }
        .resultado { margin-top: 15px; padding: 12px; background: #ecf0f1; border-radius: 4px; min-height: 30px; }
        code { background: #2c3e50; color: #2ecc71; padding: 10px; display: block; border-radius: 4px; margin: 8px 0; font-size: 13px; word-break: break-all; }
        h3 { color: #2980b9; }
        .badge { background: #16a085; color: white; padding: 2px 8px; border-radius: 10px; font-size: 12px; }
        .danger { color: #c0392b; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        td, th { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }
        th { background: #16a085; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .tab-btn { padding: 8px 16px; margin-right: 5px; border: none; cursor: pointer; border-radius: 4px 4px 0 0; font-size: 13px; background: #bdc3c7; }
        .tab-btn.active { background: #16a085; color: white; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .url-bar { background: #2c3e50; color: #ecf0f1; padding: 8px 12px; border-radius: 4px; font-family: monospace; font-size: 13px; margin: 8px 0; word-break: break-all; }
        .highlight { background: #f9ca24; padding: 0 3px; border-radius: 2px; color: #2c3e50; }
        .flow { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 15px 0; }
        .flow-step { background: #16a085; color: white; padding: 8px 14px; border-radius: 20px; font-size: 13px; }
        .flow-arrow { color: #16a085; font-size: 20px; font-weight: bold; }
    </style>
</head>
<body>

<h1>⚠️ Demo: XSS Baseado em DOM <span class="badge">DOM-based XSS</span></h1>

<div class="aviso">
    <strong>Apenas para fins de formação.</strong>
    Este ficheiro demonstra vulnerabilidades de DOM-based XSS.
    O payload <strong>nunca chega ao servidor</strong> — é processado exclusivamente pelo browser.
    Não utilizar em ambiente de produção.
</div>

<!-- ============================================================
     DEMO 1 — location.hash
     ============================================================ -->
<div class="box">
    <h2>🔬 Demo 1 — Via <code style="background:#eee;color:#c0392b;padding:2px 6px;border-radius:3px">location.hash</code></h2>
    <p>A página lê o fragmento da URL (<strong>#</strong>) e escreve-o diretamente no DOM com <code style="background:#eee;color:#c0392b;padding:2px 6px">innerHTML</code>.</p>
    <p>O servidor <span class="danger">nunca vê o payload</span> — tudo acontece no browser.</p>

    <p><strong>URL atual:</strong></p>
    <div class="url-bar" id="url-display">A carregar...</div>

    <p><strong>Conteúdo renderizado a partir do hash:</strong></p>
    <!-- ❌ VULNERÁVEL: innerHTML com location.hash sem sanitização -->
    <div class="resultado" id="output-hash">
        <em style="color:#999">Adiciona um #nome à URL para ver o resultado...</em>
    </div>

    <script>
        // Atualiza display da URL
        document.getElementById('url-display').textContent = window.location.href;

        // ❌ VULNERÁVEL: escreve o hash diretamente no DOM
        function renderHash() {
            const hash = decodeURIComponent(window.location.hash.substring(1));
            if (hash) {
                document.getElementById('output-hash').innerHTML = "Bem-vindo, " + hash + "!";
            }
        }
        renderHash();
        window.addEventListener('hashchange', function() {
            document.getElementById('url-display').textContent = window.location.href;
            renderHash();
        });
    </script>
</div>

<!-- ============================================================
     DEMO 2 — location.search (query string)
     ============================================================ -->
<div class="box">
    <h2>🔬 Demo 2 — Via <code style="background:#eee;color:#c0392b;padding:2px 6px;border-radius:3px">location.search</code></h2>
    <p>A página lê o parâmetro <strong>?tema=</strong> da URL e aplica-o ao estilo via <code style="background:#eee;color:#c0392b;padding:2px 6px">document.write()</code>.</p>

    <div id="tema-output"></div>

    <script>
        // ❌ VULNERÁVEL: document.write com parâmetro da URL
        const params = new URLSearchParams(window.location.search);
        const tema = params.get('tema');
        if (tema) {
            document.write("<p>Tema selecionado: " + tema + "</p>");
        }
    </script>
</div>

<!-- ============================================================
     DEMO 3 — input do utilizador via innerHTML
     ============================================================ -->
<div class="box">
    <h2>🔬 Demo 3 — Via input + <code style="background:#eee;color:#c0392b;padding:2px 6px;border-radius:3px">innerHTML</code></h2>
    <p>O valor de um campo de texto é inserido no DOM com <code style="background:#eee;color:#c0392b;padding:2px 6px">innerHTML</code> sem sanitização. Nenhum dado vai ao servidor.</p>

    <input type="text" id="input-nome" placeholder="Introduz o teu nome...">
    <button onclick="mostrarNome()">Mostrar</button>

    <div class="resultado" id="output-nome">
        <em style="color:#999">O resultado aparece aqui...</em>
    </div>

    <script>
        function mostrarNome() {
            const valor = document.getElementById('input-nome').value;
            // ❌ VULNERÁVEL: innerHTML sem sanitização
            document.getElementById('output-nome').innerHTML = "Olá, " + valor + "!";
        }
    </script>
</div>

<!-- ============================================================
     SECÇÃO EDUCATIVA
     ============================================================ -->
<div class="box">
    <h3>🎓 Payloads para testar</h3>

    <div>
        <button class="tab-btn active" onclick="showTab('tab1', this)">Demo 1 (hash)</button>
        <button class="tab-btn" onclick="showTab('tab2', this)">Demo 2 (search)</button>
        <button class="tab-btn" onclick="showTab('tab3', this)">Demo 3 (input)</button>
    </div>

    <div id="tab1" class="tab-content active" style="margin-top:10px">
        <p>Adiciona à URL:</p>
        <code>#&lt;img src=x onerror=alert('XSS hash')&gt;</code>
        <code>#&lt;script&gt;alert(document.cookie)&lt;/script&gt;</code>
        <code>#&lt;svg onload=alert('XSS SVG')&gt;</code>
        <p>Exemplo completo:</p>
        <code>http://localhost/xss_dom.php#&lt;img src=x onerror=alert('XSS')&gt;</code>
        <p class="danger">⚠️ O fragmento (#) nunca é enviado ao servidor — invisível nos logs!</p>
    </div>

    <div id="tab2" class="tab-content" style="margin-top:10px">
        <p>Adiciona à URL:</p>
        <code>?tema=&lt;img src=x onerror=alert('XSS query')&gt;</code>
        <code>?tema=&lt;script&gt;alert('XSS document.write')&lt;/script&gt;</code>
        <p>Exemplo completo:</p>
        <code>http://localhost/xss_dom.php?tema=&lt;script&gt;alert('XSS')&lt;/script&gt;</code>
    </div>

    <div id="tab3" class="tab-content" style="margin-top:10px">
        <p>Introduz no campo de texto:</p>
        <code>&lt;img src=x onerror=alert('XSS input')&gt;</code>
        <code>&lt;svg onload=alert('XSS SVG')&gt;</code>
        <code>&lt;b onmouseover=alert('hover XSS')&gt;passa o rato aqui&lt;/b&gt;</code>
    </div>

    <script>
        function showTab(id, btn) {
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.getElementById(id).classList.add('active');
            btn.classList.add('active');
        }
    </script>
</div>

<div class="box">
    <h3>🔄 Fluxo do ataque DOM-based XSS</h3>
    <div class="flow">
        <div class="flow-step">1. Atacante cria URL maliciosa</div>
        <div class="flow-arrow">→</div>
        <div class="flow-step">2. Vítima clica no link</div>
        <div class="flow-arrow">→</div>
        <div class="flow-step">3. Browser carrega a página</div>
        <div class="flow-arrow">→</div>
        <div class="flow-step">4. JS lê a URL</div>
        <div class="flow-arrow">→</div>
        <div class="flow-step">5. innerHTML executa o payload</div>
        <div class="flow-arrow">→</div>
        <div class="flow-step" style="background:#c0392b">6. Código malicioso executa</div>
    </div>
    <p><span class="danger">O servidor nunca processa o payload</span> — não aparece em logs, WAFs baseados em tráfego HTTP podem não detetar.</p>
</div>

<div class="box">
    <h3>📊 Comparação dos 3 tipos de XSS</h3>
    <table>
        <tr>
            <th></th>
            <th>Refletido</th>
            <th>Armazenado</th>
            <th>DOM-based</th>
        </tr>
        <tr>
            <td><strong>Onde é processado</strong></td>
            <td>Servidor</td>
            <td>Servidor + BD</td>
            <td>Browser (client-side)</td>
        </tr>
        <tr>
            <td><strong>Persiste na BD</strong></td>
            <td>Não</td>
            <td>Sim</td>
            <td>Não</td>
        </tr>
        <tr>
            <td><strong>Visível nos logs do servidor</strong></td>
            <td>Sim (na URL)</td>
            <td>Sim</td>
            <td><span class="danger">Não (com #hash)</span></td>
        </tr>
        <tr>
            <td><strong>Detetável por WAF</strong></td>
            <td>Geralmente sim</td>
            <td>Geralmente sim</td>
            <td><span class="danger">Difícil (hash)</span></td>
        </tr>
        <tr>
            <td><strong>Gravidade</strong></td>
            <td>Alta</td>
            <td>Crítica</td>
            <td>Alta / Crítica</td>
        </tr>
    </table>
</div>

<div class="box">
    <h3>🛡️ Como corrigir</h3>

    <p><strong>❌ Vulnerável:</strong></p>
    <code>element.innerHTML = "Olá, " + userInput;</code>

    <p><strong>✅ Correção 1 — usar textContent (não interpreta HTML):</strong></p>
    <code>element.textContent = "Olá, " + userInput;</code>

    <p><strong>✅ Correção 2 — sanitizar com DOMPurify:</strong></p>
    <code>element.innerHTML = DOMPurify.sanitize(userInput);</code>

    <p><strong>✅ Correção 3 — Content Security Policy (CSP):</strong></p>
    <code>Content-Security-Policy: default-src 'self'; script-src 'self'</code>

    <p><strong>Sinks perigosos a evitar:</strong></p>
    <code>
innerHTML / outerHTML<br>
document.write() / document.writeln()<br>
element.insertAdjacentHTML()<br>
eval() / setTimeout(string) / setInterval(string)<br>
window.location = userInput
    </code>
</div>

</body>
</html>
