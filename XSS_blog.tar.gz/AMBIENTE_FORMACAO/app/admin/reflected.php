<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Demo XSS Refletido – Formação</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 0 20px; background: #f5f5f5; }
        h1 { color: #c0392b; }
        .box { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .aviso { background: #fff3cd; border-left: 4px solid #f39c12; padding: 10px 15px; margin-bottom: 20px; }
        input[type=text] { width: 70%; padding: 8px; font-size: 14px; }
        input[type=submit] { padding: 8px 16px; background: #c0392b; color: white; border: none; cursor: pointer; font-size: 14px; }
        .resultado { margin-top: 15px; padding: 10px; background: #ecf0f1; border-radius: 4px; }
        code { background: #2c3e50; color: #2ecc71; padding: 10px; display: block; border-radius: 4px; margin: 8px 0; font-size: 13px; word-break: break-all; }
        h3 { color: #2980b9; }
    </style>
</head>
<body>

<h1>⚠️ Demo: XSS Refletido</h1>

<div class="aviso">
    <strong>Apenas para fins de formação.</strong>
    Este ficheiro demonstra uma vulnerabilidade real de Cross-Site Scripting (XSS) refletido.
    Não utilizar em ambiente de produção.
</div>

<!-- ============================================================
     CÓDIGO VULNERÁVEL
     O valor de $_GET['nome'] é refletido diretamente no HTML
     sem qualquer sanitização — vulnerabilidade intencional.
     ============================================================ -->
<div class="box">
    <h2>🔍 Pesquisa de utilizador</h2>
    <form method="GET" action="">
        <input type="text" name="nome" placeholder="Introduz o teu nome...">
        <input type="submit" value="Pesquisar">
    </form>

    <?php if (isset($_GET['nome'])): ?>
        <div class="resultado">
            <!-- ❌ VULNERÁVEL: entrada do utilizador sem sanitização -->
            <p>Resultados para: <?= $_GET['nome'] ?></p>
        </div>
    <?php endif; ?>
</div>

<!-- ============================================================
     SECÇÃO EDUCATIVA
     ============================================================ -->
<div class="box">
    <h3>🎓 Como explorar esta vulnerabilidade</h3>
    <p>Introduz os seguintes payloads no campo de pesquisa:</p>

    <p><strong>1. Alerta básico:</strong></p>
    <code>&lt;script&gt;alert('XSS')&lt;/script&gt;</code>

    <p><strong>2. Roubo de cookies (simulação):</strong></p>
    <code>&lt;script&gt;alert(document.cookie)&lt;/script&gt;</code>

    <p><strong>3. Redirecionamento:</strong></p>
    <code>&lt;script&gt;window.location='https://example.com'&lt;/script&gt;</code>

    <p><strong>4. Via atributo HTML (sem tag script):</strong></p>
    <code>&lt;img src=x onerror="alert('XSS via img')"&gt;</code>

    <p><strong>5. Payload na URL (para partilhar com vítima):</strong></p>
    <code>http://localhost/xss.php?nome=&lt;script&gt;alert('XSS')&lt;/script&gt;</code>
</div>

<div class="box">
    <h3>🛡️ Como corrigir</h3>
    <p>Substituir a linha vulnerável por:</p>
    <code>&lt;?= htmlspecialchars($_GET['nome'], ENT_QUOTES, 'UTF-8') ?&gt;</code>

    <p>A função <strong>htmlspecialchars()</strong> converte caracteres especiais em entidades HTML:</p>
    <ul>
        <li><code>&lt;</code> → <code>&amp;lt;</code></li>
        <li><code>&gt;</code> → <code>&amp;gt;</code></li>
        <li><code>"</code> → <code>&amp;quot;</code></li>
        <li><code>'</code> → <code>&amp;#039;</code></li>
    </ul>

    <h3>📌 Impacto real de XSS</h3>
    <ul>
        <li>Roubo de sessões/cookies de autenticação</li>
        <li>Redirecionamento para sites de phishing</li>
        <li>Keylogging (captura de teclas no browser da vítima)</li>
        <li>Defacement da página para outros utilizadores</li>
        <li>Distribuição de malware via browser</li>
    </ul>
</div>

</body>
</html>
